# angularjs-blogging
blogging system with AngularJs, PHP and MySQL


The mission is to create an online Blog, that would allow users reading the posts in blog and allow signed-in users to create and remove their posts.
